<?php echo e($slot); ?>

<?php /**PATH D:\Iman\Kuliah\Semester 6\Project Fix\laporpak\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>