<?php if (isset($component)) { $__componentOriginalaa758e6a82983efcbf593f765e026bd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa758e6a82983efcbf593f765e026bd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => $__env->getContainer()->make(Illuminate\View\Factory::class)->make('mail::message'),'data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('mail::message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
# Publikasi Laporan Dibatalkan

Halo <?php echo e($user->name); ?>,

Publikasi laporan Anda dengan ID **<?php echo e($report->id); ?>** telah dibatalkan oleh administrator.

Alasan pembatalan:
> <?php echo e($report->reason ?? 'Tidak ada alasan spesifik diberikan.'); ?>


Berikut detail laporannya:

- **Kategori**: <?php echo e($report->category); ?>

- **Deskripsi**: <?php echo e($report->description); ?>

- **Waktu Pengiriman**: <?php echo e($report->created_at->format('d M Y H:i')); ?>


Jika Anda memiliki pertanyaan, jangan ragu menghubungi kami.

Salam,<br>
<?php echo e(config('app.name')); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa758e6a82983efcbf593f765e026bd9)): ?>
<?php $attributes = $__attributesOriginalaa758e6a82983efcbf593f765e026bd9; ?>
<?php unset($__attributesOriginalaa758e6a82983efcbf593f765e026bd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa758e6a82983efcbf593f765e026bd9)): ?>
<?php $component = $__componentOriginalaa758e6a82983efcbf593f765e026bd9; ?>
<?php unset($__componentOriginalaa758e6a82983efcbf593f765e026bd9); ?>
<?php endif; ?>
<?php /**PATH D:\Iman\Kuliah\Semester 6\Project Fix\laporpak\resources\views\emails\reports\unpublished.blade.php ENDPATH**/ ?>